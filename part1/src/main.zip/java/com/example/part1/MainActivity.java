package com.example.part1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextStudentId, editTextName, editTextMajor, editTextClass;
    private RadioGroup radioGroupGender;
    private Spinner spinnerCollege;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 显示ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("2411664 施翊聪");
        }


        editTextStudentId = findViewById(R.id.editTextStudentId);
        editTextName = findViewById(R.id.editTextName);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        spinnerCollege = findViewById(R.id.spinnerCollege);
        editTextMajor = findViewById(R.id.editTextMajor);
        editTextClass = findViewById(R.id.editTextClass);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.colleges_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCollege.setAdapter(adapter);

        Button buttonExplicit = findViewById(R.id.buttonExplicit);
        Button buttonImplicit = findViewById(R.id.buttonImplicit);

        //显式跳转
        buttonExplicit.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            putExtras(intent);
            startActivity(intent);
        });

        //隐式跳转
        buttonImplicit.setOnClickListener(v -> {
            Intent intent = new Intent("com.example.part1.SECOND_ACTIVITY");
            putExtras(intent);
            startActivity(intent);
        });
    }

        //注册信息进行传递
    private void putExtras(Intent intent) {
        String studentId = editTextStudentId.getText().toString();
        String name = editTextName.getText().toString();
        int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
        String gender = (selectedGenderId == R.id.radioButtonMale) ? "男" : "女";
        String college = spinnerCollege.getSelectedItem().toString();
        String major = editTextMajor.getText().toString();
        String className = editTextClass.getText().toString();

        intent.putExtra("studentId", studentId);
        intent.putExtra("name", name);
        intent.putExtra("gender", gender);
        intent.putExtra("college", college);
        intent.putExtra("major", major);
        intent.putExtra("class", className);
    }
}
